                                    lisence mit patent Griggorii@gmail.com present mesa setting mesa-20.0.4_V5-libdrm



$ sudo tar xvpf oomox-griggorii+pop-dark.tar.xz -C /

$ sudo apt install dconf-editor

run Setting_dconf_linux_OS20.04_V5_LVDS_By_Griggorii_Focal Fossa_wayland.sh

________________________________________________________________________________________

https://github.com/Griggorii/mesa-20.0.4_V5-libdrm/tree/master

Ubuntu X64 19.04 , 20.04

Mesa download mesa-20.0.4_V5-libdrm :https://yadi.sk/d/owVXIgVxvaiLNw
